exports.myDateTime = function () {
    var d = new Date();
    return d.getSeconds();;
  };